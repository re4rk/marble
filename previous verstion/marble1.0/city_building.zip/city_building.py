city_building.py

import pygame


class land:
    def __init__(self, name, ground, house, building, hotel, landmark):
        self.name = name
        self.ground = ground
        self.house = house
        self.building = building
        self.hotel = hotel
        self.landmark = landmark

fin="""Lhasa\t1\t0\t50000\t5000\t15000\t25000\t100000\nMarrakech\t2\t0\t80000\t8000\t24000\t40000\t160000\nPetra\t3\t0\t130000\t13000\t39000\t65000\t260000\nJerusalem\t4\t0\t140000\t14000\t42000\t70000\t280000\nBeijing\t5\t0\t170000\t17000\t51000\t85000\t340000\nLalibela\t6\t0\t190000\t19000\t57000\t95000\t380000\nVenice\t7\t0\t200000\t20000\t60000\t100000\t400000\nSeville\t8\t1\t210000\t21000\t63000\t105000\t420000\nHavana\t8\t2\t220000\t22000\t66000\t110000\t440000\nAthens\t8\t3\t240000\t24000\t72000\t120000\t480000\nKathmandu\t8\t4\t240000\t24000\t72000\t120000\t480000\nHoian\t8\t5\t260000\t26000\t78000\t130000\t520000\nLuxor\t8\t6\t270000\t27000\t81000\t135000\t540000\nJaipur\t8\t7\t270000\t27000\t81000\t135000\t540000\nRiodeJaneiro\t7\t8\t300000\t30000\t90000\t150000\t600000\nLisbon\t6\t8\t20000\t32000\t96000\t160000\t640000\nAmsterdam\t5\t8\t320000\t32000\t96000\t160000\t640000\nBerlin\t4\t8\t350000\t35000\t105000\t175000\t700000\nVienna\t3\t8\t350000\t35000\t105000\t175000\t700000\nCuzco\t2\t8\t360000\t36000\t108000180000\t720000\nCartagena\t1\t8\t380000\t38000\t114000\t190000\t760000\nNewYork\t0\t7\t410000\t41000\t123000\t205000\t820000\nLondon\t0\t6\t430000\t43000\t129000\t215000\t860000\nLyon\t0\t5\t430000\t43000\t129000\t215000\t860000\nSydney\t0\t4\t460000\t46000\t138000\t230000\t920000\nPrague\t0\t3\t470000\t47000\t141000\t235000\t940000\nVatican\t0\t2\t480000\t48000\t144000\t240000\t960000\nJochiwon\t0\t1\t490000\t49000\t147000\t245000\t980000"""


up = fin.split('\n')
for i in range(0,28):
    up = fin.split('\n')
    zxc=up[i].split('\t')
    print(zxc[0],zxc[1],zxc[2],zxc[3],zxc[4],zxc[5])
    land(zxc[0], zxc[1], zxc[2], zxc[3], zxc[4],zxc[5])